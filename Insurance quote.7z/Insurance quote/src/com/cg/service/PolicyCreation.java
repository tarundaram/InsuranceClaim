package com.cg.service;

import java.util.List;

import com.cg.IQexception.IQexception;
import com.cg.controller.DAOimpl;
import com.cg.model.Policy;
import com.cg.model.PolicyDetails;

public class PolicyCreation {
	DAOimpl ea = new DAOimpl(); 
	public boolean existAccount(int accountNumber) throws IQexception {
		return ea.existAccount(accountNumber);
	}
	public String getBusinessSseg(int accountNumber) throws IQexception{
		return ea.getBuisnessSegment(accountNumber);
	}
	public String getBusinessSegID(String bus_seg) throws IQexception{
		return ea.getBusinessSegID(bus_seg);
	}
	public List<String> getQuestions(String bus_seg_id) throws IQexception
	{
		return ea.getQuestions(bus_seg_id);
	}
	public List<String> getQuestionId(String buisnessSegId) throws IQexception {
		
		return ea.getQuestionId(buisnessSegId);
	}
	public List<String> getAnswer(String question) throws IQexception{
		return ea.getAnswer(question);
	}
	public int insertPolicy(Policy policy)throws IQexception
	{
		return ea.insertPolicy(policy);
	}
	public void insertPolicyDetails(PolicyDetails pd) throws IQexception{
		ea.insertPolicyDetails(pd);
	}
	
}
