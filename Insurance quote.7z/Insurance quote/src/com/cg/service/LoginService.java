package com.cg.service;

import com.cg.IQexception.IQexception;
import com.cg.controller.DAOimpl;
import com.cg.model.Login;

public class LoginService {
	DAOimpl dao = new DAOimpl();
	public String LoginValid(Login login) throws IQexception{
		return dao.valid(login);
	}
}
