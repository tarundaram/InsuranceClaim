package com.cg.service;

import java.sql.SQLException;

import com.cg.IQexception.IQexception;
import com.cg.controller.DAOimpl;

import com.cg.model.Login;

public class ProfileCreation {
	DAOimpl pc = new DAOimpl();
		public int profilecreation(Login login) throws IQexception{
			return pc.addProfile(login);
		}
		}
		

