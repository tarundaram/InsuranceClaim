package com.cg.service;

import com.cg.IQexception.IQexception;
import com.cg.controller.DAOimpl;
import com.cg.model.Accounts;

public class Accountcreation {
	DAOimpl ac = new DAOimpl();
	public int accountcreation(Accounts account) throws IQexception{
		return ac.createAccount(account);	
	}
}
