package com.cg.IQexception;

public class IQexception extends Exception {
	private static final long serialVersionUID = 1L;
	
	public IQexception(String s){
		
		super(s);
	}
}
