package com.cg.servlet;

import java.util.List;
import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.IQexception.IQexception;
import com.cg.model.Policy;
import com.cg.model.PolicyDetails;
import com.cg.service.PolicyCreation;

/**
 * Servlet implementation class PolicyCalcServ
 */
@WebServlet("/PolicyCalcServ")
public class PolicyCalcServ extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public PolicyCalcServ() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		ServletContext cText = getServletContext();
		String que1opt=null;
		String que2opt=null;
		String que3opt= null;
		String que4opt = null;
		String que5opt= null;
		double premium = 0;
		String choice1 = request.getParameter("que1");
		if (choice1.equals("a")) {
			premium = premium + 200;
			que1opt = cText.getAttribute("que1ans1").toString();
		} else if (choice1.equals("b")) {
			premium = premium + 400;
			que1opt = cText.getAttribute("que1ans2").toString();
		} else if (choice1.equals("c")) {
			premium = premium + 600;
			que1opt = cText.getAttribute("que1ans3").toString();
		}
		String choice2 = request.getParameter("que2");
		if (choice2.equals("a")) {
			premium = premium + 200;
			que2opt = cText.getAttribute("que2ans1").toString();
		} else if (choice2.equals("b")) {
			premium = premium + 400;
			que2opt = cText.getAttribute("que2ans2").toString();
		} else if (choice2.equals("c")) {
			premium = premium + 600;
			que2opt = cText.getAttribute("que2ans3").toString();
		}
		String choice3 = request.getParameter("que3");
		if (choice3.equals("a")) {
			premium = premium + 200;
			que3opt = cText.getAttribute("que3ans1").toString();
		} else if (choice3.equals("b")) {
			premium = premium + 400;
			que3opt = cText.getAttribute("que3ans2").toString();
		} else if (choice3.equals("c")) {
			premium = premium + 600;
			que3opt = cText.getAttribute("que3ans3").toString();
		}
		String choice4 = request.getParameter("que4");
		if (choice4.equals("a")) {
			premium = premium + 200;
			que4opt = cText.getAttribute("que4ans1").toString();
		} else if (choice4.equals("b")) {
			premium = premium + 400;
			que4opt = cText.getAttribute("que4ans2").toString();
		} else if (choice4.equals("c")) {
			premium = premium + 600;
			que4opt = cText.getAttribute("que4ans3").toString();
		}
		String choice5 = request.getParameter("que5");
		if (choice5.equals("a")) {
			premium = premium + 200;
			que5opt = cText.getAttribute("que5ans1").toString();
		} else if (choice5.equals("b")) {
			premium = premium + 400;
			que5opt = cText.getAttribute("que5ans2").toString();
		} else if (choice5.equals("c")) {
			premium = premium + 600;
			que5opt = cText.getAttribute("que5ans3").toString();
		}
		 System.out.println(premium);
		int accountnumber= (int) cText.getAttribute("accountnumber");
		PolicyCreation pc= new PolicyCreation();
		try {
		String	bus_seg = pc.getBusinessSseg(accountnumber);
		String bus_seg_id = pc.getBusinessSegID(bus_seg);
		List<String> que = pc.getQuestions(bus_seg_id);
		List<String> quesIdList = pc.getQuestionId(bus_seg_id);
		Policy policy =  new Policy(premium,accountnumber);
		int policyNumber = pc.insertPolicy(policy);
		String quesId[]=new String[que.size()];
		int k = 0;
		for(String questionId: quesIdList) {
			quesId[k]=questionId;
			k++;
		}	
		PolicyDetails pd1 = new PolicyDetails(policyNumber,quesId[0],que1opt);
		PolicyDetails pd2 = new PolicyDetails(policyNumber,quesId[0],que2opt);
		PolicyDetails pd3 = new PolicyDetails(policyNumber,quesId[0],que3opt);
		PolicyDetails pd4 = new PolicyDetails(policyNumber,quesId[0],que4opt);
		PolicyDetails pd5 = new PolicyDetails(policyNumber,quesId[0],que5opt);
		pc.insertPolicyDetails(pd1);
		pc.insertPolicyDetails(pd2);
		pc.insertPolicyDetails(pd3);
		pc.insertPolicyDetails(pd4);
		pc.insertPolicyDetails(pd5);
		} catch (IQexception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
	}

}
