package com.cg.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.IQexception.IQexception;
import com.cg.service.PolicyCreation;

/**
 * Servlet implementation class PolicyCreationServ
 */
@WebServlet("/PolicyCreationServ")
public class PolicyCreationServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PolicyCreationServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		boolean b = false;
		
		int accountNumber = Integer.parseInt(request.getParameter("accountnumber"));
		PolicyCreation pc= new PolicyCreation();
		RequestDispatcher rd;
		try{
			b = pc.existAccount(accountNumber);
		if(b){
				String bus_seg = pc.getBusinessSseg(accountNumber);
				String bus_seg_id = pc.getBusinessSegID(bus_seg);
				List<String> que = pc.getQuestions(bus_seg_id);
				List<String> quesIdList = pc.getQuestionId(bus_seg_id);	
				ServletContext cText = getServletContext();
				cText.setAttribute("accountnumber", accountNumber);
				
			List<String> ans = pc.getAnswer(que.get(0));
			request.setAttribute("que1ans1",ans.get(0));
			request.setAttribute("que1ans2",ans.get(1));
			request.setAttribute("que1ans3",ans.get(2));
			
			List<String> ans2 = pc.getAnswer(que.get(0));
			cText.setAttribute("que1ans1",ans2.get(0));
			cText.setAttribute("que1ans2",ans2.get(1));
			cText.setAttribute("que1ans3",ans2.get(2));
			
			
			ans = pc.getAnswer(que.get(1));
			request.setAttribute("que2ans1",ans.get(0));
			request.setAttribute("que2ans2",ans.get(1));
			request.setAttribute("que2ans3",ans.get(2));
			
			ans2 = pc.getAnswer(que.get(1));
			cText.setAttribute("que2ans1",ans.get(0));
			cText.setAttribute("que2ans2",ans.get(1));
			cText.setAttribute("que2ans3",ans.get(2));
			
			ans = pc.getAnswer(que.get(2));
			request.setAttribute("que3ans1",ans.get(0));
			request.setAttribute("que3ans2",ans.get(1));
			request.setAttribute("que3ans3",ans.get(2));
			
			ans2 = pc.getAnswer(que.get(2));
			cText.setAttribute("que3ans1",ans.get(0));
			cText.setAttribute("que3ans2",ans.get(1));
			cText.setAttribute("que3ans3",ans.get(2));
			
			ans = pc.getAnswer(que.get(3));
			request.setAttribute("que4ans1",ans.get(0));
			request.setAttribute("que4ans2",ans.get(1));
			request.setAttribute("que4ans3",ans.get(2));
			
			ans = pc.getAnswer(que.get(3));
			cText.setAttribute("que4ans1",ans.get(0));
			cText.setAttribute("que4ans2",ans.get(1));
			cText.setAttribute("que4ans3",ans.get(2));
			
			ans = pc.getAnswer(que.get(4));
			request.setAttribute("que5ans1",ans.get(0));
			request.setAttribute("que5ans2",ans.get(1));
			request.setAttribute("que5ans3",ans.get(2));
			
			ans2 = pc.getAnswer(que.get(4));
			cText.setAttribute("que5ans1",ans.get(0));
			cText.setAttribute("que5ans2",ans.get(1));
			cText.setAttribute("que5ans3",ans.get(2));
			
			
			request.setAttribute("question1",que.get(0));
			request.setAttribute("question2",que.get(1));
			request.setAttribute("question3",que.get(2));
			request.setAttribute("question4",que.get(3));
			request.setAttribute("question5",que.get(4));
			
				rd = request.getRequestDispatcher("polcre.jsp");
				rd.forward(request, response);
		}
		}
		catch(IQexception e){
			e.printStackTrace();
		}
		 
	}
}

	
					
		
		
	


