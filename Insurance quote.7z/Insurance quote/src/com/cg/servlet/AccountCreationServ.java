package com.cg.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.IQexception.IQexception;
import com.cg.model.Accounts;
import com.cg.service.Accountcreation;

/**
 * Servlet implementation class AccountCreationServ
 */
@WebServlet("/AccountCreationServ")
public class AccountCreationServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
      RequestDispatcher rd= null; 
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AccountCreationServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String insname = request.getParameter("name");
		String state = request.getParameter("state");
		String city =request.getParameter("city");
		int zip = Integer.parseInt(request.getParameter("zip"));
		String street = request.getParameter("street");
		String busseg= request.getParameter("busseg");	
		String username=request.getParameter("username");
		Accounts acc = new Accounts(insname,street,city,state,zip,busseg,username);
		Accountcreation  acr= new Accountcreation();
		try {
			int acctno= acr.accountcreation(acc);
		} catch (IQexception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
