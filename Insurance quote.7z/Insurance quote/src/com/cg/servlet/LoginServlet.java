package com.cg.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.IQexception.IQexception;
import com.cg.model.Login;
import com.cg.service.LoginService;

/**
 * Servlet implementation class Login
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	RequestDispatcher rd=null;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		// TODO Auto-generated method stub
		Login login = new Login(request.getParameter("uname"),request.getParameter("pswrd"));
		LoginService ls = new LoginService(); 
		try {
			if(ls.LoginValid(login).equals("Admin")){
				request.setAttribute("name",request.getParameter("uname"));
				 rd = request.getRequestDispatcher("Admin.jsp");
		    rd.forward(request, response);
			}
			else if (ls.LoginValid(login).equals("Agent")){
				request.setAttribute("name",request.getParameter("uname"));
				rd = request.getRequestDispatcher("Agent.jsp");
				rd.forward(request, response);
			}
				
			else if(ls.LoginValid(login).equals("Insured")){
				request.setAttribute("name",request.getParameter("uname"));
				rd = request.getRequestDispatcher("Insured.jsp");
				rd.forward(request, response);
			}
			else response.sendRedirect("error.jsp");
		} catch (IQexception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}


