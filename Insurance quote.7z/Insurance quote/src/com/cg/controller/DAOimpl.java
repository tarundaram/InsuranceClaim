package com.cg.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.IQexception.IQexception;
import com.cg.model.Accounts;
import com.cg.model.Login;
import com.cg.model.Policy;
import com.cg.model.PolicyDetails;

public class DAOimpl {
	Connection connection = null;
	String driverName = "oracle.jdbc.OracleDriver";
	String url = "jdbc:oracle:thin:@localhost:1521:XE";
	String username = "KONDEPATISAICHARIT";
	String password = "Cenation7.";

	public Connection getConnection() {
		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
			connection = DriverManager.getConnection(url, username, password);
			System.out.println("connection established");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}
	//VALID LOGINNNNN
	public String  valid(Login login) throws IQexception{
		
		ResultSet rs= null;
		PreparedStatement st=null;
		String role =null;
		connection = getConnection();
			try{
				st = connection.prepareStatement("select * from user_role where user_name=? and password=?");	
				st.setString(1, login.getUserName());
				st.setString(2,login.getPassword());
				rs = st.executeQuery();
				while (rs.next()) {		
					String dummyu =  rs.getString(1);
					String dummyp = rs.getString(2);
					if(dummyu.equals(login.getUserName()) && dummyp.equals(login.getPassword())){
						role = rs.getString(3);
						break;	
			}
				}
			}
				catch(SQLException e){
					throw new IQexception("unable to validate");
				}
		return role;
	}
	//ADDDDD PROFILEEEE
	public int addProfile(Login login) throws IQexception{
		int record= 0;
		PreparedStatement st=null;
		connection = getConnection();
			
		try{
			st = connection.prepareStatement("INSERT INTO user_role values(?,?,?)");
		
			st.setString(1, login.getUserName());
			st.setString(2, login.getPassword());
			st.setString(3, login.getRoleCode());
			record = st.executeUpdate();
				st.close();
				connection.close();
		}
		catch(SQLException e){
			throw new IQexception("unable to add profile.");
		}
		return record;
	}
	//CREATEE ACCOUNTTTT
	public int createAccount(Accounts account) throws IQexception {
		int accountNumber = 0;
		ResultSet resultSet = null;
		PreparedStatement st=null;
		connection = getConnection();
		try{
			st = connection.prepareStatement("insert into Accounts values(acc_seq.nextval,?,?,?,?,?,?,?)");
		
			st.setString(1, account.getInsuredName());
			st.setString(2, account.getInsuredStreet());
			st.setString(3, account.getInsuredCity());
			st.setString(4, account.getInsuredState());
			st.setInt(5, account.getInsuredZip());
			st.setString(6, account.getBusinessSegment());
			st.setString(7, account.getUserName());
			st.executeUpdate();
			
			// System.out.println("Hello");
			st = connection.prepareStatement("select acc_seq.currval from dual");
			resultSet = st.executeQuery();	
			resultSet.next();
			accountNumber = resultSet.getInt(1);
			connection.commit();
				connection.rollback();
				resultSet.close();
				st.close();		
				connection.close();
		}
		catch(SQLException e){
			throw new IQexception("unable to create account");
		}
				return accountNumber;
		}
	//CHECKS IF ACCOUNT IS IN DATA BASE
	public boolean existAccount(int accountNumber) throws IQexception{
		boolean validAccountFlag = false;
		ResultSet resultSet = null;
		PreparedStatement st = null;
		connection = getConnection();
			try {
				st = connection.prepareStatement("SELECT * FROM accounts");		
			resultSet = st.executeQuery();
			while (resultSet.next()) {
				if (accountNumber == resultSet.getInt(1)) {
					validAccountFlag = true;
					break;
				}
			}
				st.close();
				connection.close();
			}
	 catch (SQLException e) {
		throw new IQexception("unable to check if the exist account is there or not");
	}	
		return validAccountFlag;
}	
	//GET BUSINESS SEGMENT
	public String getBuisnessSegment(int accountNumber) throws IQexception{
		String buisnessSegment = "";
		ResultSet resultSet = null;
		PreparedStatement st = null;
		connection = getConnection();
		try{
			st = connection.prepareStatement("SELECT * FROM accounts WHERE account_number=?");
			st.setInt(1, accountNumber);
			resultSet = st.executeQuery();
			resultSet.next();
			buisnessSegment = resultSet.getString(7);
			st.close();
			connection.close();
	}
		catch(SQLException e){
			throw new IQexception("unable to retreive business segment");
			}
		return buisnessSegment;
		}
	//GET BUSINESS SEGMENT ID
	public String getBusinessSegID(String bus_seg) throws IQexception{
		System.out.println(bus_seg);
		String buisnessSegmentId = null;
		ResultSet resultSet = null;
		PreparedStatement st = null;
		connection = getConnection();
		try {
			st = connection.prepareStatement("SELECT * FROM business_segment WHERE bus_seg_name=?");
			st.setString(1, bus_seg);
			resultSet = st.executeQuery();
			resultSet.next();
			buisnessSegmentId = resultSet.getString(1);	
			st.close();
			connection.close();
			}
			catch (SQLException e) {
				throw new IQexception("unable to get business segment id");
				}
		return buisnessSegmentId;

}
	//GET QUESTIONS FROM DB
	public List<String> getQuestions(String buisnessSegId) throws IQexception {
		List<String> questionList = new ArrayList<>();
		ResultSet resultSet = null;
		connection = getConnection();
		PreparedStatement st=null;
		try {
			st = connection.prepareStatement("SELECT * from policy_questions WHERE BUS_SEG_ID=?");
			st.setString(1, buisnessSegId);
			resultSet = st.executeQuery();
			while (resultSet.next()) {
				questionList.add(resultSet.getString(4));
			}
				st.close();
				connection.close();
		}
		catch(SQLException e){
			throw new IQexception("unable to get questions");
		}
		return questionList;
	}
	//GET ANSWERS
	public List<String> getAnswer(String string) throws IQexception{
		List<String> answerList = new ArrayList<>();
		ResultSet resultSet = null;
		String answer1 = "";
		String answer2 = "";
		String answer3 = "";
		PreparedStatement st = null;
		connection = getConnection();
		
		try {
			st = connection.prepareStatement("SELECT * from policy_questions WHERE POL_QUES_DESC=?");
			st.setString(1, string);
			resultSet = st.executeQuery();
			while (resultSet.next()) {
				answer1 = resultSet.getString(5);
				answerList.add(answer1);
				answer2 = resultSet.getString(7);
				answerList.add(answer2);
				answer3 = resultSet.getString(9);
				answerList.add(answer3);
			}
				st.close();
				connection.close();
		}
		catch(SQLException e){
			throw new IQexception("unable to get answers");
		}
		return answerList;
	}
	public List<String> getQuestionId(String buisnessSegId) throws IQexception {
		List<String> questionIdList = new ArrayList<>();
		ResultSet resultSet = null;
		PreparedStatement st=null;
		connection = getConnection();
		
		try {
			st = connection.prepareStatement("SELECT * from policy_questions WHERE BUS_SEG_ID=?");

			st.setString(1, buisnessSegId);

			resultSet = st.executeQuery();

			while (resultSet.next()) {
				questionIdList.add(resultSet.getString(1));
			}
				st.close();	
				connection.close();
		}
		catch(SQLException e){
			throw new IQexception("unable to get questionID");
		}
		return questionIdList;
	}
	public int insertPolicy(Policy policy) throws IQexception {
		int policyNumber = 0;
		ResultSet resultSet = null;	
		PreparedStatement st = null;
		connection = getConnection();
		try {
			st = connection.prepareStatement("INSERT INTO policy values(policy_number_seq.nextval,?,?,?)");
			st.setDouble(1, policy.getPolicyPremium());
			st.setInt(2, policy.getAccountNumber());
			st.setString(3, policy.getUsername());
			st.executeUpdate();
			st = connection.prepareStatement("select policy_number_seq.currval from dual");
			resultSet = st.executeQuery();
			resultSet.next();
			policyNumber = resultSet.getInt(1);
			connection.commit();
				connection.rollback();
				resultSet.close();
				st.close();
				connection.close();
		}
		catch(SQLException e){
			throw new IQexception("unable to insert policy");
			}
			
		return policyNumber;
	}
	public void insertPolicyDetails(PolicyDetails pd) throws IQexception{
	
		PreparedStatement st=null;
			connection = getConnection();
			try {
				st = connection.prepareStatement("INSERT INTO policy_details VALUES(?,?,?)");
				st.setInt(1, pd.getPolicyNumber());
				st.setString(2, pd.getQuestionID());
				st.setString(3, pd.getAnswer());
				st.executeUpdate();
				connection.commit();
				connection.rollback();
				st.close();
				connection.close();
				} catch (SQLException e) {
					throw new IQexception("unable to close connection object");
				}
			}
	}


