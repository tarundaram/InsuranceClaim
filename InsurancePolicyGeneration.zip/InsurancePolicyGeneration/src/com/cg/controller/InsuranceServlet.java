package com.cg.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.exception.InsuranceException;
import com.cg.service.IInsuranceGenService;
import com.cg.service.InsuranceGenServiceImpl;

/**
 * Servlet implementation class InsuranceServlet
 */
@WebServlet("*.ins")
public class InsuranceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       IInsuranceGenService service=new InsuranceGenServiceImpl();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsuranceServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	      String url=request.getServletPath().trim();
	      String resource=null;
	      String message=null;
	      switch(url) 
	      {
	      case "/login.ins" :
	    	  String username=request.getParameter("username");
	    	  
	    	  String password=request.getParameter("password");
	    	  try {
				String role=service.loginValidation(username, password);
                if(role.equals("admin"))
                {
                	resource="admin.jsp";
                }
                 else if(role.equals("agent"))
                {
                	resource="agent.jsp";
                }   	  
                 else if(role.equals("insurer"))
                 {
                 	resource="insurer.jsp";
                 }   	  
                 else if(role.equals("insurerl"))
                 {
                 	resource="insurerl.jsp";
                 }
                 else if(role.isEmpty())
                 {
                	 throw new InsuranceException("Invalid Credentials");
                 }
	    	  } catch (InsuranceException e) {
				message=e.getMessage();}
				resource="login.jsp";
				request.setAttribute("message", message);
			
	    	 break;
	      }
	      RequestDispatcher rd=request.getRequestDispatcher(resource);
    	  rd.forward(request, response);
	}

}
