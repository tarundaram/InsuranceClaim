package com.cg.service;

import com.cg.exception.InsuranceException;

public interface IInsuranceGenService 
{
   public String loginValidation(String username,String password) throws InsuranceException;
}
