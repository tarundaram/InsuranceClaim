package com.cg.service;

import com.cg.dao.IInsuranceGenDao;
import com.cg.dao.InsuranceGenDaoImpl;
import com.cg.exception.InsuranceException;

public class InsuranceGenServiceImpl implements IInsuranceGenService
{
    IInsuranceGenDao dao=new InsuranceGenDaoImpl();
	@Override
	public String loginValidation(String username, String password) throws InsuranceException {
	 String role=dao.loginValidation(username, password);
		return role;
	}
}
