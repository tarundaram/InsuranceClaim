package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.exception.InsuranceException;
import com.cg.util.UtilConn;

public class InsuranceGenDaoImpl implements IInsuranceGenDao {

	@Override
	public String loginValidation(String username, String password) throws InsuranceException 
	{
		String query1="select role from userrole where username=? and password=?";
		System.out.println(username);
		System.out.println(password);
		String role="";
		try {
			Connection con=UtilConn.getConnection();
			
//			PreparedStatement ps=con.prepareStatement(query,ResultSet.TYPE_SCROLL_INSENSITIVE);
			PreparedStatement stmt=con.prepareStatement("select role from userrole where username=? and password=?");
			//Statement stmt=con.createStatement(query1);
			System.out.println("hello world");
			stmt.setString(1, username);
			stmt.setString(2, password);
			ResultSet rs=stmt.executeQuery();
			if(rs.next())
			{
				role=rs.getString("role");
				con.close();
			}
			else
			{
				throw new InsuranceException("Invalid Credentials");
			}
			
		} catch (SQLException e) {
			 e.printStackTrace();
		}
		return role;
	}

}
