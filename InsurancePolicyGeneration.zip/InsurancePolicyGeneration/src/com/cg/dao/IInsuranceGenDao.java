package com.cg.dao;

import com.cg.exception.InsuranceException;

public interface IInsuranceGenDao 
{
	   public String loginValidation(String username,String password) throws InsuranceException;
}
